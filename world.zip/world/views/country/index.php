<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

$this->title = 'Countries';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="country-index">


<h1><?= Html::encode($this->title) ?></h1>



<?php
?>

<?= GridView::widget([
'dataProvider' => $dataProvider,
'filterModel' => $searchModel,
'columns' => [

[
'class' => ActionColumn::className(),
'urlCreator' => function ($action, $model, $key, $index, $column) {
return Url::toRoute([$action, 'Code' => $model->Code]);
}
],
'Code',


[
'label' => 'naam',
'attribute' => 'Name',
'contentOptions' => ['style' => '  font-weight: bold;'],
],

[
'label' => 'Hoofdstad',
'attribute' => 'Capital',
'contentOptions' => ['style' => 'width: 10px; white-space: normal;'],
'format' => 'raw',
'value' => function ($data) {

    return Html::a('naar hoofdstad', ['/city/index', 'CitySearch[ID]' => $data->Capital]);
}

],

[
'label' => 'Inwoners',
'attribute' => 'Population',
'contentOptions' => ['style' => 'width:30px; white-space: normal;'],
],

[
'label' => 'Oppervlakte',
'attribute' => 'SurfaceArea',
'contentOptions' => ['style' => 'width:30px; white-space: normal;'],
'format' => 'raw',
'value' => function ($data) {

return sprintf("%8d k&#13217", $data->SurfaceArea);
                }
            ],

[
'label' => 'Bevolkingsdichtheid',
'value' => function ($data) {

return sprintf('%8d ', $data->Population / $data->SurfaceArea);
}


],
    ],
        ]); ?>

<p> <?= Html::a('Create Country', ['create'], ['class' => 'btn btn-success']) ?> </p>

</div>