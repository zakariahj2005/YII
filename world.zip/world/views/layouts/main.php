<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Html;
use yii\bootstrap4\Nav;
use yii\bootstrap4\NavBar;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<header>
 <?php
	// plaats deze code in de main.php en vervang daarmee de standaard menu

    NavBar::begin([
      
     // hier wordt het type en de stijl van de menu bepaald
       'brandLabel' => Yii::$app->name,  // de naam van het menu
       'brandUrl' => Yii::$app->homeUrl, // de home page waar je naar toe gaat als je op de naam klikt
       'options' => [
          'class' => 'navbar-inverse navbar-fixed-top', // de Bootstrap 4 style van het menu
        ],
      
   ]);
                  
                  
    echo Nav::widget([
      
      // hier worden de menu's en menu items bepaald
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            [ 'label' => 'Country',
                'items' => [
                    ['label' => 'Overzicht', 'url' => ['/country/index', ''] ],
                             ['label' => 'Voeg toe', 'url' => ['/country/index', ''] ],

                    ['label' => 'Europa', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'Europe'] ],

                    ['label' => 'Azië', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'Asia'] ],

                    ['label' => 'Afrika', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'Africa'] ],

                    ['label' => 'Antarctica', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'Antarctica'] ],
 
                    ['label' => 'Noord-America', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'North-America'] ],
 
                    ['label' => 'Zuid-America', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'South-America'] ],
                     
                  ['label' => 'Oceanië', 'url' => ['/country/index', 'Countrysearch[Continent]'=>'Oceania'] ],

                ],
            ],
        ],

    'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            [ 'label' => 'City',
                'items' => [
                    ['label' => 'Overzicht', 'url' => ['/country/index', ''] ],
                    
                             ['label' => 'Voeg toe', 'url' => ['/country/index', ''] ],
                ],
            ],
        ],
    ]);
                  
   NavBar::end();
 ?> 
</header>

<main role="main" class="flex-shrink-0">
    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</main>

<footer class="footer mt-auto py-3 text-muted">
    <div class="container">
        <p class="float-left">&copy; My Company <?= date('Y') ?></p>
        <p class="float-right"><?= Yii::powered() ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
